"use strict";
var Global = (function () {
    function Global() {
    }
    return Global;
}());
Global.BASE_USER_ENDPOINT = 'api/listitemapi';
exports.Global = Global;
//# sourceMappingURL=global.js.map