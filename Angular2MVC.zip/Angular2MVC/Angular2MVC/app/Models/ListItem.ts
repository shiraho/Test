﻿export interface IListItem {
    Id: Number
    Type: Boolean
    Name: String
    State: Boolean
    Description: String
    Status: Boolean 
}